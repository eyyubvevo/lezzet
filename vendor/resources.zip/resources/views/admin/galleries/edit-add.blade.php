@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span
                    class="text-muted fw-light">Slayderlər /</span> {{ isset($gallery) ?'Yenilə' : 'Şəkil Əlavə Et' }}
            </h4>
            <div class="row">
                <div class="col-xxl">
                    <div class="card mb-4">

                        <div class="card-body">
                            <form
                                action="{{ isset($gallery) ? route('admin.galleries.update',['id' => $gallery->id]) : route('admin.galleries.store')}}"
                                method="post"
                                enctype="multipart/form-data">
                                @csrf
                                @if(isset($gallery))
                                    @method('PUT')
                                @else
                                    @method('POST')
                                @endif
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="media_type">Yükləyəcəyiniz Tipi
                                        Seçin</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="type" id="media_type">
                                            <option>Zəhmət olmazsa seçin</option>
                                            <option @if(isset($gallery) && $gallery->type) selected @endif  value="1">
                                                Şəkil
                                            </option>
                                            <option @if(isset($gallery) && !$gallery->type) selected @endif  value="0">
                                                Video
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div id="photo_input" class="row mb-3">
                                    <h5 class="card-header">Şəkli</h5>
                                    <!-- Account -->
                                    <div class="card-body">
                                        <div class="d-flex align-items-start align-items-sm-center gap-4">
                                            <img
                                                src=" @if(isset($gallery) && $gallery->image) {{ asset('storage/'.$gallery->image) }} @else {{asset('backend/assets/img/default.jpg')}} @endif"
                                                alt="Gallery-avatar"
                                                class="d-block rounded"
                                                height="100"
                                                width="100"
                                                id="uploadedAvatar"
                                            />
                                            <div class="button-wrapper">
                                                <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                                    <span class="d-none d-sm-block">Upload new photo</span>
                                                    <i class="bx bx-upload d-block d-sm-none"></i>
                                                    <input
                                                        type="file"
                                                        id="upload"
                                                        class="account-file-input"
                                                        hidden
                                                        name="image"
                                                        @if(!isset($gallery)) required @endif
                                                        accept="image/png, image/jpeg"
                                                    />
                                                </label>
                                                <button type="button"
                                                        class="btn btn-outline-secondary account-image-reset mb-4">
                                                    <i class="bx bx-reset d-block d-sm-none"></i>
                                                    <span class="d-none d-sm-block">Reset</span>
                                                </button>

                                                <p class="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="video_input" class="row mb-3">
                                    @if(isset($gallery))
                                        <iframe width="300" height="360" src="https://www.youtube.com/embed/{{$gallery->video_link}}" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>                                    @endif
                                    <label class="col-sm-2 col-form-label" for="button_url">Video ID</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="video_link" name="video_link"
                                               placeholder="Video id-sini daxil edin..." required
                                               @if(isset($gallery)) value="{{$gallery->video_link}}" @endif
                                        />
                                    </div>
                                </div>

                                <div id="gallery_status" class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="is_featured">Statusu</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="is_featured" name="is_featured">
                                            <option @if(isset($gallery) && $gallery->is_featured) selected
                                                    @endif value="1">
                                                Aktiv
                                            </option>
                                            <option @if(isset($gallery) && !$gallery->is_featured) selected
                                                    @endif value="0">Gözləmədə
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row justify-content-end">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endsection
        @push('scripts')

            <script>
                $(document).ready(function () {
                    var photo_input = $('#photo_input');
                    var video_input = $('#video_input');
                    var gallery_status = $('#gallery_status');

                    $('#is_featured, #media_type').select2();

                    @if(isset($gallery) && $gallery->type == '0')
                    gallery_status.show();
                    photo_input.hide();
                    video_input.show();
                    $('#video_link').prop('required', true);
                    $('#upload').prop('required', false);
                    @elseif(isset($gallery) && $gallery->type == '1')
                    gallery_status.show();
                    photo_input.show();
                    video_input.hide();
                    $('#upload').prop('required', false);
                    $('#video_link').prop('required', false);
                    @endif
                    @if(!isset($gallery))
                    $('#photo_input, #video_input, #gallery_status').hide();
                    @endif
                    $('#media_type').on('change', function () {
                        var selectedValue = $(this).val();

                        if (selectedValue === '1') {
                            gallery_status.fadeIn();
                            photo_input.fadeIn();
                            video_input.hide();
                            $('#upload').prop('required', true);
                            $('#video_link').prop('required', false);
                        } else if (selectedValue === '0') {
                            gallery_status.fadeIn();
                            photo_input.hide();
                            video_input.fadeIn();
                            $('#video_link').prop('required', true);
                            $('#upload').prop('required', false);
                        } else {
                            photo_input.hide();
                            video_input.hide();
                            gallery_status.hide();
                        }
                    });
                });


            </script>
    @endpush
