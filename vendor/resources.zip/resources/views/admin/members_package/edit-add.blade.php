@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span
                    class="text-muted fw-light">üzvlük Paketləri /</span> {{ isset($member_package) ? $member_package->name. ' Yenilə' : 'Üzv Paketi Əlavə Et' }}
            </h4>
            <div class="row">
                <div class="col-xxl">
                    <div class="card mb-4">

                        <div class="card-body">
                            <form
                                action="{{ isset($member_package) ? route('admin.members_package.update',['id' => $member_package->id]) : route('admin.members_package.store')}}"
                                method="post"
                                enctype="multipart/form-data">
                                @csrf
                                @if(isset($member_package))
                                    @method('PUT')
                                @else
                                    @method('POST')
                                @endif

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="name">Üzv Paketi adı</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="name" name="name"
                                               placeholder="Üzv Paketi adını daxil edin..." required
                                               @if(isset($member_package)) value="{{$member_package->name}}" @endif
                                        />
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="is_active">Üzv Paketi Statusu</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="is_active" name="is_active">
                                            <option @if(isset($member_package) && $member_package->is_active) selected
                                                    @endif value="1">Aktiv
                                            </option>
                                            <option @if(isset($member_package) && !$member_package->is_active) selected
                                                    @endif value="0">Gözləmədə
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="is_registration">Üzv Paketi Qeydiyyat Statusu</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="is_registration" name="is_registration">
                                            <option @if(isset($member_package) && $member_package->is_registration) selected
                                                    @endif value="1">Açıq
                                            </option>
                                            <option @if(isset($member_package) && !$member_package->is_registration) selected
                                                    @endif value="0">Qapalı
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row justify-content-end">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endsection
        @push('scripts')
            <script>
                $(document).ready(function () {
                    $('#is_active').select2();
                    $('#is_registration').select2();
                });
            </script>
    @endpush
