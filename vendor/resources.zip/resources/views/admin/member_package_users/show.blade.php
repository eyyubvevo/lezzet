@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col">
                    <div class="card mb-4">
                        <h5 class="card-header">Üzvlük İstəyi</h5>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Əlaqədar şəxs (Adı Soyadı)</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            {{$member_package_users->fullname}}
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Şirkət Adı</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            {{$member_package_users->company_name}}
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Fəaliyyət istiqaməti</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            {{$member_package_users->areas_activity}}
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Telefon Nömrəsi</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            {{$member_package_users->phone}}
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Emaili</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            {{$member_package_users->email}}
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Vəzifəsi</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            <mark>{{$member_package_users->position}}</mark>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Ölkə</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            <mark>{{$member_package_users->country}}</mark>
                                        </p>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="align-middle"><small class="text-light fw-semibold">Şəhər</small></td>
                                    <td class="py-3">
                                        <p class="mb-0">
                                            <mark>{{$member_package_users->city}}</mark>
                                        </p>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
