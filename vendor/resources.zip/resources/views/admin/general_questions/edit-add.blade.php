@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span
                    class="text-muted fw-light">Tez Tez Verilən Suallar /</span> {{ isset($general_questions) ? $general_questions->title. ' Yenilə' : 'Tez Tez Verilən Suallara Əlavə Et' }}
            </h4>
            <div class="row">
                <div class="col-xxl">
                    <div class="card mb-4">

                        <div class="card-body">
                            <form
                                action="{{ isset($general_questions) ? route('admin.general_questions.update',['id' => $general_questions->id]) : route('admin.general_questions.store')}}"
                                method="post"
                                enctype="multipart/form-data">
                                @csrf
                                @if(isset($general_questions))
                                    @method('PUT')
                                @else
                                    @method('POST')
                                @endif
                                <hr class="my-0"/>
                                <br>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="question">Sual</label>
                                    <div class="col-sm-10">
                                        @foreach($languages as $language)
                                            <input type="text" class="form-control" id="question_{{ $language }}"
                                                   name="question_{{ $language }}"
                                                   placeholder="Sualı {{ $language }} dilində daxil edin..." required
                                                   @if(isset($general_questions)) value="{{$general_questions->getTranslation('question',$language)}}" @endif
                                            />
                                            <br>
                                        @endforeach
                                    </div>
                                </div>
                                <hr class="my-0"/>
                                <br>
                                <hr class="my-0"/>
                                <br>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="answer">Cavab</label>
                                    <div class="col-sm-10">
                                        @foreach($languages as $language)
                                            <textarea name="answer_{{ $language }}" id="answer_{{ $language }}">
                                            @if(isset($general_questions))
                                                    {!! $general_questions->getTranslation('answer',$language) !!}
                                                @endif
                                        </textarea>
                                            <br>
                                        @endforeach
                                    </div>
                                </div>
                                <hr class="my-0"/>
                                <br>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="is_published">Statusu</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="is_published" name="is_published">
                                            <option
                                                @if(isset($general_questions) && $general_questions->is_published) selected
                                                @endif value="1">Aktiv
                                            </option>
                                            <option
                                                @if(isset($general_questions) && !$general_questions->is_published) selected
                                                @endif value="0">Gözləmədə
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row justify-content-end">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endsection
        @push('scripts')
            <script>
                @foreach($languages as $language)
                ClassicEditor
                    .create(document.querySelector('#answer_{{ $language }}'), {
                        ckfinder : {
                            uploadUrl: "{{route('admin.general_questions.upload',['_token' => csrf_token()])}}"
                        },
                        height: '600px',
                        placeholder: '{{'Cavabı '. $language.' dilində daxil edin...' }}'
                    })
                    .catch(error => {
                        console.error(error);
                    });
                @endforeach
                $(document).ready(function () {
                    $('#is_published').select2();
                });
            </script>
    @endpush
