@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])

    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>Üzv ol</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->

    <div class="container">

        <form action="{{route('members.registration.store')}}" method="POST" class="member-register-form">
            @csrf
            @method('POST')
            <h2>{{$member_package->name}} {{__('website.register_to_become_member')}}</h2>
            <input type="hidden" name="package_id" value="{{ $member_package->id }}">
            <input type="text" placeholder="{{__('website.company_name')}}" name="company_name" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.areas_activity')}}" name="areas_activity" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.fullname')}}" name="fullname" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.position')}}" name="position" class="member-register-input" required>
            <input type="email" placeholder="E-mail" name="email" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.telephone_number')}}" name="phone" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.country')}}" name="country" class="member-register-input" required>
            <input type="text" placeholder="{{__('website.city')}}" name="city" class="member-register-input" required>
            <div class="member-register-btn">
                <button type="submit">{{__('website.become_member')}}</button>
            </div>
        </form>

    </div>
    @include('front.layouts.footer')
@endsection
