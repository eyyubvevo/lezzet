@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>  {{__('website.activities')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->



    <!--== Start Service Area Wrapper ==-->
    <div class="service-area-wrapper sm-top-wt">

        <!-- <div class="service-area-top parallax" data-parallax-speed="0.75" data-bg="assets/img/service/service-bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-xl-5 m-auto text-center">

                    </div>
                </div>
            </div>
        </div> -->

        <div class="service-content-area" style="margin-top: 100px;">
            <div class="container">
                <div class="row mtn-30">
                    @foreach($activities as $activity)
                        <div class="col-sm-6 col-lg-4">
                            <!-- Start Service Item -->
                            <div class="service-item">
                                <figure class="service-thumb">
                                    <a href="{{route('activity.news',['id'=> $activity->id,'slug' => $activity->slug])}}"><img
                                            src="{{asset('storage/'.$activity->image)}}"
                                            alt=""/></a>

                                    <figcaption class="service-txt">
                                        <h5>{{$activity->name}}</h5>
                                    </figcaption>
                                </figure>
                            </div>
                            <!-- End Service Item -->
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    @include('front.layouts.footer')
@endsection
