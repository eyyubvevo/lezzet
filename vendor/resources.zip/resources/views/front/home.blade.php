@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])

 <!--== Start Slider Area Wrapper ==-->
        @foreach($sliders as $slider)
            <div class="cover-area">
        <div class="cover-slider">
            <div class="cover-img">
              <img src="{{asset('storage/'.$slider->image)}}" alt="">
            </div>
          </div>

            <div class="cover-area__content">
                <h2>{{$slider->title}}</h2>
                <p>{!! $slider->description !!}</p>
            </div>
        </div>
          @endforeach







    <!--== Start Slider Area Wrapper ==-->
    <!--<div class="slider-area-wrapper">-->
    <!--    <div id="rev_slider_11_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="  -classic"-->
    <!--         data-source="gallery">-->

    <!--        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">-->
    <!--            <div class="carousel-inner">-->
    <!--                @foreach($sliders as $slider)-->
    <!--                    <div class="carousel-item active">-->
    <!--                        <img class="d-block w-100" src="{{asset('storage/'.$slider->image)}}" alt="First slide">-->
    <!--                    </div>-->
    <!--                    <div style="" class="carousel-caption d-none d-md-block">-->
    <!--                        <div class="tp-caption tp-resizeme slide-heading">{{$slider->title}}</div>-->
    <!--                        <div class="tp-caption tp-resizeme slide-txt">{!! $slider->description !!}</div>-->
    <!--                        <a href="{{$slider->button_url}}"-->
    <!--                           class="tp-caption Button-Outline-Secondary rev-btn">{{$slider->button_text}}</a>-->
    <!--                    </div>-->
    <!--                @endforeach-->
    <!--            </div>-->
    <!--            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">-->
    <!--                <span class="carousel-control-prev-icon" aria-hidden="true"></span>-->
    <!--                <span class="sr-only">{{__('website.previous')}}</span>-->
    <!--            </a>-->
    <!--            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">-->
    <!--                <span class="carousel-control-next-icon" aria-hidden="true"></span>-->
    <!--                <span class="sr-only">{{__('website.next')}}</span>-->
    <!--            </a>-->
    <!--        </div>-->

    <!--    </div>-->
    <!--</div>-->
    <!--== End Slider Area Wrapper ==-->

    <!--== Start About Area Wrapper ==-->
    <div class="about-area-wrapper sm-top">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-5">
                    <figure class="about-thumb">
                        <img src="{{asset('storage/'.$about->image)}}" alt=" -About"/>
                    </figure>
                </div>

                <div class="col-md-6 col-lg-7">
                    <div class="about-content">
                        <h2>{{$about->title}}</h2>
                        <p><strong> </strong> {!! $about->short_content !!}</p>
                        <a href="{{route('about')}}" class="btn-about">{{__('website.more_details')}} <i class="fa-sharp fa-solid fa-caret-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End About Area Wrapper ==-->

    <!--== Start Feature Area Wrapper ==-->
    <div class="feature-area-wrapper sm-top">
        <div class="container">
            <div class="row mtn-sm-60 mtn-md-5">
                @foreach($services as $service)
                    <div class="col-md-4">
                        <div class="icon-box-item">
                            <div class="icon-box__icon">
                                <img src="{{asset('storage/'.$service->icon)}}" alt=" -Feature"/>
                            </div>
                            <div class="icon-box__info">
                                <h5>{{$service->title}}</h5>
                                <p>{!! $service->description !!} </p>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    <!--== End Feature Area Wrapper ==-->

    <!--== Start Service Area Wrapper ==-->
    <div class="service-area-wrapper sm-top-wt" id="activities">
        <div class="service-area-top parallax" data-parallax-speed="0.75" data-bg="assets/img/service/service-bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-xl-5 m-auto text-center">
                        <div class="section-title section-title--light">
                            <h2 class="mb-0">{{__('website.activities')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="service-content-area">
            <div class="container">
                <div class="row mtn-30">
                    @foreach($activities as $activity)
                        <div class="col-sm-6 col-lg-4">
                            <!-- Start Service Item -->

                            <div class="service-item">
                                <figure class="service-thumb">
                                    <a href="{{route('activity.news',['id'=> $activity->id,'slug' => $activity->slug])}}"><img
                                            src="{{asset('storage/'.$activity->image)}}"
                                            alt=""/></a>

                                    <figcaption class="service-txt">
                                        <h5>{{$activity->name}}</h5>
                                    </figcaption>
                                </figure>
                            </div>

                            <!-- End Service Item -->
                        </div>
                    @endforeach
                </div>

            </div>
        </div>
    </div>
    <!--== End Service Area Wrapper ==-->

    <!--== Start Fun Fact Area Wrapper ==-->
    <div class="fun-fact-area sm-top parallax" data-parallax-speed="0.70" data-bg="assets/img/fun-fact-bg.jpg">
       <div class="container">
            <div class="row mtn-40">
               <div class="col-6 col-md-3 text-center">
                    <div class="counter-item">
                       <h2 class="counter-number"><span class="counter">15</span></h2>
                       <h6 class="counter-txt">Üzv</h6>
                   </div>
               </div>

               <div class="col-6 col-md-3 text-center">
                    <div class="counter-item">
                        <h2 class="counter-number"><span class="counter">1</span></h2>
                      <h6 class="counter-txt">Tədbir</h6>
                   </div>
               </div>

               <div class="col-6 col-md-3 text-center">
                   <div class="counter-item">
                       <h2 class="counter-number"><span class="counter">2</span></h2>
                        <h6 class="counter-txt">Seminar/workshop</h6>
                    </div>
              </div>


                <div class="col-6 col-md-3 text-center">
                   <div class="counter-item">
                        <h2 class="counter-number"><span class="counter">2</span></h2>
                       <h6 class="counter-txt">Sahə/şirkət ziyarəti</h6>
                   </div>
               </div>
           </div>
        </div>
    </div>
    <!--== End Fun Fact Area Wrapper ==-->

    <!--== Start Blog Area Wrapper ==-->
    <div class="blog-area-wrapper sm-top">

        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="section-title">
                        <h2 class="mb-0">{{__('website.news')}}</h2>
                    </div>
                </div>
            </div>

            <div class="blog-content-wrapper">
                <div class="row mtn-30">
                    @foreach($news as $new)
                        <div class="col-md-4">
                            <div class="blog-item">
                                <figure class="blog-thumb">
                                    <a href="{{route('news.show',['id' => $new->id,'slug' => $new->slug])}}"><img src="{{asset('storage/'.$new->image)}}" alt=" -Blog"/></a>
                                </figure>
                                <div class="blog-content">
                                    <h2 class="h5"><a href="">{{$new->title}}</a></h2>
                                    <p>{!! $new->short_content !!}</p>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div style="display: flex; justify-content: end;">
                <a href="" class="view-btn">{{__('website.more_details')}}</a>
            </div>
        </div>
    </div>
    <!--== End Blog Area Wrapper ==-->

    <!--== Start Brand Logo Area Wrapper ==-->
    <div class="brand-logo-area sm-top">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="section-title">
                        <h2 class="mb-0">{{__('website.partners')}}</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="brand-logo-content slick-row-20">
                        @foreach($partners as $partner)
                            <div class="brand-logo-item">
                                <a href="#"><img src="{{asset('storage/'.$partner->logo_path)}}" alt=" -Logo"/></a>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Brand Logo Area Wrapper ==-->

  @include('front.layouts.footer')
@endsection
