@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <!--== Start Page Header Area ==-->
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{__('website.about')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->

    <!--== Start About Area Wrapper ==-->
    <div class="home-two-about-area">
        <div class="container">
            <div class="row align-items-center">


                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="about-content about-content--2">
                        <h2>{{$about->title}}</h2>
                        <p><strong> </strong> {!! $about->content !!}</p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                    <figure class="about-thumb">
                        <img src="{{ asset('storage/'.$about->image) }}" alt=" -About"/>
                    </figure>
                </div>
            </div>
        </div>
    </div>
    <!--== End About Area Wrapper ==-->


    <div class="faq-area-wrapper sm-top-wt">
        <div class="container">
            <div class="row mtn-50" >
                <div class="col-12">
                    <!-- General Question Faq Start-->
                    <div class="single-subject-by-faq-wrap">

                        <h2>{{__('website.general_questions')}}</h2>

                        <div class="general-question-faq brand-accordion">
                            <div class="accordion" id="generalQuestions">
                                @foreach($general_questions as $genral)
                                    <div class="card">
                                        <div class="card-header" id="heading{{$genral->id}}">
                                            <h5 class="mb-0">
                                                <button class="btn collapsed" type="button" data-bs-toggle="collapse"
                                                        data-bs-target="#collapse{{$genral->id}}"> {{$genral->question}}</button>
                                            </h5>
                                        </div>
                                        <div id="collapse{{$genral->id}}" class="collapse" data-bs-parent="#generalQuestions">
                                            <div class="card-body">
                                                {!! $genral->answer !!}
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <!-- General Question Faq End-->
                </div>


            </div>
        </div>
    </div>

    @include('front.layouts.footer')
@endsection
