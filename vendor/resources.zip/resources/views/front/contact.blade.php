@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>  {{__('website.contact')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->

    <!--== Start Contact Page Area Wrapper ==-->
    <div class="contact-page-area-wrapper sp-y">
        <div class="container">
            <div class="contact-content-wrap">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="contact-form-area contact-method">
                            <h3>{{__('website.send_to_message')}}</h3>

                            <div class="contact-form-wrap">
                                <form action="{{route('contact.store')}}" method="post">
                                    @csrf
                                    @method('POST')
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label>
                                                    <input type="text" name="name" placeholder="{{__('website.first_name')}}"
                                                           required/>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label>
                                                    <input type="text" name="lastname" placeholder="{{__('website.last_name')}}" required/>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label>
                                                    <input type="email" name="email" placeholder="{{__('website.email')}}"
                                                           required/>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label>
                                                    <input type="text" name="phone" placeholder="{{__('website.phone')}}"/>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="single-input-item">
                                                <label for="con_message" class="sr-only m-0"></label>
                                                <textarea name="message" id="con_message" cols="30" rows="7"
                                                          placeholder="{{__('website.message')}}" required></textarea>
                                            </div>

                                            <div class="single-input-item mb-0 mt-40">
                                                <button type="submit" class="btn-outline">{{__('website.message_send')}}</button>
                                            </div>

                                            <div class="form-message"></div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="contact-information contact-method">
                            <div class="contact-info-con">
                                <h3>{{__('website.contact_info')}}</h3>

                                <div class="widget-item m-0">
                                    <address>
                                        {{setting('address')}}
                                        <br>
                                      {{setting('email')}}
                                        <br>
                                     {{setting('phone')}}
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="display: flex; align-items: center; justify-content: center; margin-top: 100px;">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12151.372524495608!2d49.8606967!3d40.4123258!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40307d19b69f1c19%3A0x463ae90eb750b8ac!2smarkup%20agency!5e0!3m2!1sen!2saz!4v1699444437884!5m2!1sen!2saz" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
    @include('front.layouts.footer')
@endsection
