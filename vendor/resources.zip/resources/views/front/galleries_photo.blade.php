@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <!--== Start Page Header Area ==-->
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{__('website.photos')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>
    <br>
    <section>
        <div class="container">
            <div class="row mb-100">
                @foreach($images as $image)
                    <div class="galery-column col-lg-4 col-md-6 mb-30" data-aos="flip-down">
                        <img src="{{asset('storage/'.$image->image)}}" onclick="openModal();currentSlide(1)"
                             class="galery-hover-shadow">
                    </div>
                @endforeach

            </div>
        </div>
    </section>


    <div id="galery-myModal" class="galery-modal">
        <span class="galery-close cursor" onclick="closeModal()">&times;</span>
        <div class="galery-modal-content">

            @foreach($images as $key => $image)
                <div class="galery-mySlides">
                    <div class="galery-numbertext">{{$key + 1}} / {{count($images)}}</div>

                    <img src="{{asset('storage/'.$image->image)}}" style="width:100%">
                </div>
            @endforeach

            <!-- Next/previous controls -->
            <a class="galery-prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="galery-next" onclick="plusSlides(1)">&#10095;</a>

        </div>
    </div>

    @include('front.layouts.footer')
@endsection
@push('scripts')
    <script>
        // Open the Modal
        function openModal() {
            document.getElementById("galery-myModal").style.display = "block";
        }

        // Close the Modal
        function closeModal() {
            document.getElementById("galery-myModal").style.display = "none";
        }

        var slideIndex = 1;
        showSlides(slideIndex);

        // Next/previous controls
        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        // Thumbnail image controls
        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            var i;
            var slides = document.getElementsByClassName("galery-mySlides");
            var dots = document.getElementsByClassName("galery-demo");
            var captionText = document.getElementById("galery-caption");
            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length
            }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
            captionText.innerHTML = dots[slideIndex - 1].alt;
        }
    </script>
@endpush
