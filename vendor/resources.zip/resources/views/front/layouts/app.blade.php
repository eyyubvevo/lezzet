<!DOCTYPE html>
<html class="no-js" lang="{{ str_replace('_', '-', app()->getLocale()) }}">


<!-- Mirrored from template.hasthemes.com/ / /index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Nov 2023 11:27:21 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="theme-color" content="#000000"/>
    <title>{{ setting('title') }}</title>
    <!--== Favicon ==-->
    <meta property="og:title" content="ASTA" />
    <meta property="og:type" content="article" />
    <meta property="og:url" content="{{route('home')}}" />
    <meta property="og:image" content="{{asset('storage/'.setting('logo'))}}" />
    <!-- <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon"/> -->

    <!--== Google Fonts ==-->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--== All Magnific Popup CSS ==-->
    <link href="{{asset('frontend/assets/css/magnific-popup.min.css')}}" rel="stylesheet"/>
    <!--== All Animate CSS ==-->
    <link href="{{asset('frontend/assets/css/animate.min.css')}}" rel="stylesheet"/>
    <!--== All FontAwesome CSS ==-->
    <link href="{{asset('frontend/assets/css/font-awesome.min.css')}}" rel="stylesheet"/>
    <!--== All Material Icons CSS ==-->
    <link href="{{asset('/frontend/assets/css/materialdesignicons.min.css')}}" rel="stylesheet"/>
    <!--== All Helper CSS ==-->
    <link href="{{asset('frontend/assets/css/helper.min.css')}}" rel="stylesheet"/>
    <!--== All Revolution CSS ==-->
    <link href="{{asset('frontend/assets/css/settings.css')}}" rel="stylesheet"/>
    <!--== All Slicknav CSS ==-->
    <link href="{{asset('frontend/assets/css/slicknav.min.css')}}" rel="stylesheet"/>
    <!--== All Timeline CSS ==-->
    <link href="{{asset('frontend/assets/css/timeline.css')}}" rel="stylesheet"/>
    <!--== All Slick Slider CSS ==-->
    <link href="{{asset('frontend/assets/css/slick.min.css')}}" rel="stylesheet"/>
    <!--== All BootStrap CSS ==-->
    <link href="{{asset('frontend/assets/css/bootstrap.min.css')}}" rel="stylesheet"/>
    <!--== Main Style CSS ==-->
    <link href="{{asset('frontend/assets/css/style.min.css')}}" rel="stylesheet"/>

    <!--[if lt IE 9]>
    <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    @stack('styles')
</head>

<body>

@yield('content')

<!--=======================Javascript============================-->
<script src="{{asset('frontend/assets/js/modernizr-3.6.0.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/jquery.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/jquery-migrate.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/waypoint.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/counterup.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/instafeed.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/jquery.appear.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/jquery.slicknav.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/parallax.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/slick.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/plugins/magnific-popup.min.js')}}"></script>

<!--=== Active Js ===-->
<script src="{{asset('frontend/assets/js/active.min.js')}}"></script>

<!-- REVOLUTION JS FILES -->
<script src="{{asset('frontend/assets/js/revslider/jquery.themepunch.tools.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/jquery.themepunch.revolution.min.js')}}"></script>


<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.actions.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.carousel.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.kenburn.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.layeranimation.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.migration.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.navigation.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.parallax.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.slideanims.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/revslider/extensions/revolution.extension.video.min.js')}}"></script>

<!--=== REVOLUTION JS ===-->
<script src="{{asset('frontend/assets/js/revslider/rev-active.js')}}"></script>
<script>

    document.addEventListener('DOMContentLoaded', function () {
        // Carousel initialize
        $('#carouselExampleControls').carousel();

        // Carousel pause on click
        $('#carouselExampleControls').carousel({
            pause: 'hover'
        });

        // Go to the previous item
        $('#carouselExampleControls').on('click', '.carousel-control-prev', function (e) {
            e.preventDefault();
            $('#carouselExampleControls').carousel('prev');
        });

        // Go to the next item
        $('#carouselExampleControls').on('click', '.carousel-control-next', function (e) {
            e.preventDefault();
            $('#carouselExampleControls').carousel('next');
        });
    });


</script>
@stack('scripts')
</body>

</html>
