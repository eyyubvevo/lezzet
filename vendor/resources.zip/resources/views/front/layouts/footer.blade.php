<!--== Start Footer Area Wrapper ==-->
<footer class="footer-area">

    <div class="footer-widget-area sm-top-wt">
        <div class="container">
            <div class="row mtn-40">
                <div class="col-lg-4 order-4 order-lg-0">
                    <div class="widget-item">
                        <div class="about-widget">
                            <a href="{{route('home')}}"><img src="{{ asset('storage/'.setting('footer_logo')) }}" alt="Logo"/></a>
                            <p>{!!  setting('footer_content')  !!}</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-lg-3 ms-auto">
                    <div class="widget-item">
                        <h4 class="widget-title">{{__('website.informations')}}</h4>
                        <div class="widget-body">
                            <ul class="widget-list">
                                <li><a href="{{route('home')}}">{{__('website.home')}}</a></li>
                                <li><a href="{{route('about')}}">{{__('website.about')}}</a></li>
                                <li><a href="{{route('activities')}}">{{__('website.activities')}}</a></li>
                                <li><a href="{{route('news')}}">{{__('website.news')}}</a></li>
{{--                                <li><a href="#">Üzvlərimiz</a></li>--}}
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- <div class="col-md-4 col-lg-2 ms-auto">
                    <div class="widget-item">
                        <h4 class="widget-title">Quick Links</h4>
                        <div class="widget-body">
                            <ul class="widget-list">
                                <li><a href="#">Facebook</a></li>
                                <li><a href="#">Twitter</a></li>
                                <li><a href="#">Dribbble</a></li>
                                <li><a href="#">Instagram</a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->

                <div class="col-md-4 col-lg-3">
                    <div class="widget-item">
                        <h4 class="widget-title">{{__('website.contact')}}</h4>
                        <div class="widget-body">
                            <address>
                                {{setting('address')}} <br>
                                {{setting('phone')}}
                            </address>
{{--                            <div class="member-social-icons mt-30">--}}
{{--                                <a href="#" style="color: #0E2F50; width: 30px; height: 30px;"><i--}}
{{--                                        class="mdi mdi-facebook"></i></a>--}}
{{--                                <a href="#" style="color: #0E2F50; width: 30px; height: 30px;"><i--}}
{{--                                        class="mdi mdi-twitter"></i></a>--}}
{{--                                <a href="#" style="color: #0E2F50; width: 30px; height: 30px;"><i--}}
{{--                                        class="mdi mdi-linkedin"></i></a>--}}
{{--                            </div>--}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container" style="text-align: center; margin-top: 40px;">
        <div class="copyright-txt d-flex justify-content-center  gap-2">
            <p style="font-size: 15px;">&copy;2023</p>
            <div class="markup-agency">
                <h5 style="font-size: 15px;">VEB SAYT
                    <a href="https://www.markup.az/" class="footer-markup">MARKUP.AZ</a>
                    TƏRƏFİNDƏN HAZIRLANIB</h5>
            </div>
        </div>
    </div>


</footer>
<!--== End Footer Area Wrapper ==-->

<!-- Scroll Top Button -->
<button class="btn-scroll-top"><i class="fas fa-angle-up"></i></button>

<!-- Start Off Canvas Menu Wrapper -->
<aside class="off-canvas-wrapper off-canvas-cog">
    <div class="off-canvas-overlay"></div>
    <div class="off-canvas-inner">
        <div class="close-btn">
            <button class="btn-close"><i class="mdi mdi-close"></i></button>
        </div>

        <!-- Start Off Canvas Content -->
        <div class="off-canvas-content mb-sm-30">
            <div class="off-canvas-item">
                <div class="log-in-content-wrap">
                    <h2>Login</h2>
                    <div class="login-form mtn-15">
                        <form action="#" method="post">
                            <div class="form-input-item">
                                <label for="username" class="sr-only">Username</label>
                                <input type="text" id="username" placeholder="Username" required>
                            </div>

                            <div class="form-input-item">
                                <label for="password" class="sr-only">Password</label>
                                <input type="password" id="password" placeholder="Password" required>
                            </div>

                            <div class="form-input-item">
                                <button type="submit" class="btn-submit">Login</button>
                            </div>
                        </form>
                    </div>

                    <div class="sign-up-notification">
                        <p>Not Resisted? <a href="#">Create Account Now.</a></p>
                    </div>
                </div>
            </div>

            <div class="off-canvas-item mt-sm-30">
                <div class="social-icons">
                    <a href="https://facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a>
                    <a href="https://instagram.com/" target="_blank"><i class="fa fa-instagram"></i></a>
                    <a href="https://dribbble.com/" target="_blank"><i class="fa fa-dribbble"></i></a>
                    <a href="https://pinterest.com/" target="_blank"><i class="fa fa-pinterest"></i></a>
                </div>
                <div class="copyright-content">
                    <p>&copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        Ltd. All Rights Reserved.
                    </p>
                </div>
            </div>
        </div>
    </div>
</aside>

<!-- Start Off Canvas Menu Wrapper -->
<aside class="off-canvas-wrapper off-canvas-menu">
    <div class="off-canvas-overlay"></div>
    <div class="off-canvas-inner">
        <!-- Start Off Canvas Header -->
        <div class="close-btn">
            <button class="btn-close"><i class="mdi mdi-close"></i></button>
        </div>

        <!-- Start Off Canvas Content -->
        <div class="off-canvas-content">
            <div class="res-mobile-menu">

            </div>
        </div>
    </div>
</aside>
