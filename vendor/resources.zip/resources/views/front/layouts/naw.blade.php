<div class="container-fluid page-header">
    <span>{{ setting('phone') }}</span>
    <span>{{ setting('email') }}</span>
</div>

<div class="navigation">
    <img style="width: 150px;margin-top: 10px; margin-left: 30px;" src="" alt="">

    <span class="navigation-close">&times;</span>

    <nav class="toggle-nav">
        <ul>
            <li><a href="{{route('home')}}">{{__('website.home')}}</a></li>
            <li><a href="{{route('about')}}">{{__('website.about')}}</a></li>
            <li>
                <a href="{{route('activities')}}" class="dropdown-toggle">{{__('website.activities')}}</a>
                <ul class="dropdown-container">
                    @foreach($activities as $activity)
                        <li>
                            <a href="{{ route('activity.news', ['id' => $activity->id, 'slug' => $activity->slug]) }}">{{ $activity->name }}</a>
                        </li>
                    @endforeach
                </ul>
            </li>

            <li><a href="{{route('members.categories')}}">{{__('website.membership')}}</a></li>

            <!-- <li><a href="events.html">Tədbirlər</a></li> -->
            <li><a href="{{route('news')}}">{{__('website.news')}}</a></li>
            <li><a href="#" class="dropdown-toggle">{{__('website.gallery')}}</a>
                <ul class="dropdown-container">
                    <li><a href="{{route('photos')}}">{{__('website.photos')}}</a></li>
                    <li><a href="{{route('videos')}}">{{__('website.videos')}}</a></li>
                </ul>
            </li>
            <li><a href="{{route('contact')}}">{{__('website.contact')}}</a></li>
            <li><a href="#" class="dropdown-toggle"> Dil Seç</a>
                <ul class="dropdown-container">
                    @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                        <li><a rel="alternate" hreflang="{{ $localeCode }}"
                               href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                                {{ $properties['native'] }}
                            </a></li>
                    @endforeach
                </ul>
            </li>
        </ul>
    </nav>
</div>
<!--== Start Header Area Wrapper ==-->
<header class="header-area">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class=" col-xl-2 col-lg-2 col-md-2 col-5">
                <!-- Start Logo Area -->
                <div class="logo-area">
                    <a href="{{route('home')}}"><img src="{{ asset('storage/'.setting('logo')) }}" alt="asta-Logo"></a>
                </div>
                <!-- End Logo Area -->
            </div>

            <div class=" col-xl-10 col-lg-10  d-none d-lg-block">
                <!-- Start Navigation Area -->
                <div class="navigation-area">
                    <ul class="main-menu nav">
                        <li class="has-submenu"><a href="{{route('home')}}">{{__('website.home')}}</a></li>
                        <li class="has-submenu"><a href="{{route('about')}}">{{__('website.about')}}</a></li>
                        <li class="has-submenu"><a href="{{route('activities')}}">{{__('website.activities')}}</a>
                            <ul class="submenu-nav">
                                @foreach($activities as $activity)
                                    <li>
                                        <a href="{{route('activity.news',['id'=>$activity->id, 'slug' => $activity->slug])}}">{{$activity->name}}</a>
                                    </li>
                                @endforeach
                            </ul>
                        </li>
                        <li class="has-submenu"><a href="{{route('members.categories')}}">{{__('website.membership')}}</a></li>

                        <!-- <li class="has-submenu"><a href="events.html">Tədbirlər</a></li> -->
                        <li class="has-submenu"><a href="{{route('news')}}">{{__('website.news')}}</a></li>
                        <li class="has-submenu"><a href="#">{{__('website.gallery')}}</a>
                            <ul class="submenu-nav">
                                <li><a href="{{route('photos')}}">{{__('website.photos')}}</a></li>
                                <li><a href="{{route('videos')}}">{{__('website.videos')}}</a></li>
                            </ul>
                        </li>
                        <li class="has-submenu"><a href="{{route('contact')}}">{{__('website.contact')}}</a></li>

                        <li style="color: #0dcaf0" class="has-submenu">Dil Seç
                            <ul class="submenu-nav">
                                @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                                    <li><a rel="alternate" hreflang="{{ $localeCode }}"
                                           href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                                            {{ $properties['native'] }}
                                        </a></li>
                                @endforeach
                            </ul>
                        </li>

                    </ul>


                </div>
                <!-- End Navigation Area -->
            </div>
            <div class="col-md-7  col-7">

                <button class="hamburger">
                    <div id="bar1" class="bar"></div>
                    <div id="bar2" class="bar"></div>
                    <div id="bar3" class="bar"></div>
                </button>

            </div>
        </div>


    </div>
</header>
<!--== End Header Area Wrapper ==-->
