@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <!--== Start Page Header Area ==-->
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{__('website.member_packages')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->
    <div class="container" style="margin-top: 100px; margin-bottom: 200px;">
        <div class="row" style="justify-content: center;">

            @foreach($member_packages as $package)
                <div class="col=xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="member-categories-cart">
                        <a href="{{route('members',['id' => $package->id])}}"><h2 class="member-title">{{$package->name}}</h2></a>
                        <div class="member-register-links">
                            <div class="member-register-link">
                                <a href="{{route('members',['id' => $package->id])}}">{{__('website.our_members')}}</a>
                            </div>
                            <div class="member-register-link">
                                @if($package->is_registration)
                                    <a href="{{route('members.registration',['id' => $package->id])}}">{{__('website.become_member')}}</a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>
    @include('front.layouts.footer')
@endsection
