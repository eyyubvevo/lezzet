@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <!--== Start Page Header Area ==-->
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{__('website.videos')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->


    <!-- video area  -->
    <!-- <div class="container">
        <div class="video-container">
            <div class="video-single"> <video src="assets/img/cover-video.mp4" muted></video></div>
            <div class="video-single"> <video src="assets/img/IMAGINE FOR 1 MINUTE.mp4" muted></video></div>
            <div class="video-single"> <video src="assets/img/cover-video.mp4" muted></video></div>
            <div class="video-single"> <video src="assets/img/cover-video.mp4" muted></video></div>
            <div class="video-single"> <video src="assets/img/cover-video.mp4" muted></video></div>
            <div class="video-single"> <video src="assets/img/cover-video.mp4" muted></video></div>
        </div>

        <div class="popup-video">
            <span>&times;</span>
            <video src="assets/img/cover-video.mp4"  autoplay muted controls></video>
        </div>
    </div> -->


    <!-- vide area end  -->


    <section style="padding-top: 3rem">
        <div id="video_container" class="container">
            <div class="event-procedur-header">
                <h2 style="margin-top: 100px;"></h2>
                <!--<h2 style="margin-top: 100px;">Video Arxiv </h2>-->
            </div>

            <div class="row video-area">

                {{--            <div class="col-lg-4 col-md-6 col-sm-6 col-12">--}}
                {{--                <div class="vid youtube" style="background-image:url('./assets/img/  -1.jpg');background-size: cover;"--}}
                {{--                     ytSrc="46x9Rezj4eo"></div>--}}
                {{--            </div>--}}
                @foreach($videos as $video)
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <iframe style="width: 300px;" width="200" height="200"
                                src="https://www.youtube.com/embed/{{$video->video_link}}" title=""
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                    </div>
                @endforeach


            </div>
        </div>
    </section>
    @include('front.layouts.footer')
@endsection
@push('scripts')
    <script src="{{asset('frontend/assets/js/BigPicture.js')}}"></script>
    <script>
        ;(function () {
            // other stuff
            function setClickHandler(id, fn) {
                document.getElementById(id).onclick = fn
            }

            setClickHandler('video_container', function (e) {
                var className = e.target.className
                if (~className.indexOf('htmlvid')) {
                    BigPicture({
                        el: e.target,
                        vidSrc: e.target.getAttribute('vidSrc'),
                    })
                } else if (~className.indexOf('vimeo')) {
                    BigPicture({
                        el: e.target,
                        vimeoSrc: e.target.getAttribute('vimeoSrc'),
                    })
                } else if (~className.indexOf('twin-peaks')) {
                    BigPicture({
                        el: e.target,
                        ytSrc: e.target.getAttribute('ytSrc'),
                        dimensions: [1226, 900],
                    })
                } else if (~className.indexOf('youtube')) {
                    BigPicture({
                        el: e.target,
                        ytSrc: e.target.getAttribute('ytSrc'),
                    })
                }
            })

        })()
    </script>
@endpush
