@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])
    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-12 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{$activity->name}}</h2>

                            <div class="breadcrumb-wrap">
                                <ul class="breadcrumb">
                                    <li><a href="{{route('home')}}">{{__('website.home')}}</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== End Page Header Area ==-->

    <!--== Start Page Content Area Wrapper ==-->
    <div class="service-details-wrapper sm-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="service-details-content">
                        <figure class="service-details-thumb">
                            <img src="{{asset('storage/'.$activity->image)}}" alt=" -Service Details"/>
                        </figure>
                        <div class="service-details-info">
                        {!! $activity->description !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('front.layouts.footer')
@endsection
