@extends('front.layouts.app')
@section('content')
    @include('front.layouts.naw', ['activities' => $activities])

    <div class="page-header-area bg-img" data-bg="{{asset('frontend/assets/img/page-header.jpg')}}">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 m-auto text-center">
                    <div class="page-header-content-inner">
                        <div class="page-header-content">
                            <h2>{{__('website.news')}}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="blog-page-content-area sp-y">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="blog-content-wrapper">
                        <div class="row mtn-30">

                            @foreach($news as $new)
                                <div class="col-md-6">
                                    <div class="blog-item">
                                        <figure class="blog-thumb">
                                            <a href="{{route('news.show',['id' => $new->id,'slug' => $new->slug])}}"><img src="{{asset('storage/'.$new->image)}}"
                                                                            alt=" -Blog"/></a>
                                        </figure>
                                        <div class="blog-content">
                                            <h2 class="h5"><a href="">{{$new->title}}</a></h2>
                                            <p>{!! $new->short_content !!}</p>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    <div class="pagination-wrap">
                        <ul class="pagination">
                            @if ($news->onFirstPage())
                                <li class="disabled"><span>&laquo;</span></li>
                            @else
                                <li><a href="{{ $news->previousPageUrl() }}" rel="prev">&laquo; {{__('website.previous')}}</a></li>
                            @endif

                            @foreach ($news as $page => $url)
                                @if ($page == $news->currentPage())
                                    <li class="active"><span>{{ $page }}</span></li>
                                @else
                                    <li><a href="{{ $url }}">{{ $page }}</a></li>
                                @endif
                            @endforeach

                            @if ($news->hasMorePages())
                                <li><a href="{{ $news->nextPageUrl() }}" rel="next">{{__('website.next')}} &raquo;</a></li>
                            @else
                                <li class="disabled"><span>Next &raquo;</span></li>
                            @endif
                        </ul>
                    </div>

                </div>

                <div class="col-lg-3">
                    <aside class="sidebar-area-wrapper mt-md-80 mt-sm-60">
                        <!-- Start Single Sidebar Wrap -->
                        {{--                        <div class="single-sidebar-item-wrap">--}}
                        {{--                            <h3 class="sidebar-title">Tags</h3>--}}
                        {{--                            <div class="sidebar-body">--}}
                        {{--                                <ul class="sidebar-list">--}}
                        {{--                                    <li><a href="#">Design</a></li>--}}
                        {{--                                    <li><a href="#">Furniture</a></li>--}}
                        {{--                                    <li><a href="#">Interior</a></li>--}}
                        {{--                                    <li><a href="#">Lifestyle</a></li>--}}
                        {{--                                    <li><a href="#">Media</a></li>--}}
                        {{--                                </ul>--}}
                        {{--                            </div>--}}
                        {{--                        </div>--}}
                        <!-- End Single Sidebar Wrap -->

                        <!-- Start Single Sidebar Wrap -->
                        <div class="single-sidebar-item-wrap">
                            <h3 class="sidebar-title">Featured Posts</h3>
                            <div class="sidebar-body">
                                <div class="latest-blog-widget">

                                    @foreach($news as $new)
                                    <div class="single-blog-item">
                                        <div class="post-thumb">
                                            <a href="{{route('news.show',['id' => $new->id,'slug' => $new->slug])}}"><img src="{{asset('storage/'.$new->image)}}"
                                                                            alt="Thumb"/></a>
                                        </div>

                                        <div class="post-info">
                                            <h6><a href="">{{$new->title}}</a></h6>
                                            <span class="post-date"><i class="fa fa-clock-o"></i>{{strftime('%d %B %Y', strtotime($new->created_at))}}</span>
                                        </div>
                                    </div>
                                    @endforeach

                                </div>
                            </div>
                        </div>

                        <!-- Start Single Sidebar Wrap -->
                        <!-- <div class="single-sidebar-item-wrap">
                            <div class="sidebar-body">
                                <div class="sidebar-newsletter">
                                    <h3>Newsletter</h3>
                                    <form action="#" method="post">
                                        <input type="email" placeholder="Your Email Address"/>
                                        <button class="btn btn-brand">Subscribe</button>
                                    </form>
                                </div>
                            </div>
                        </div> -->


                    </aside>
                </div>
            </div>
        </div>
    </div>
    @include('front.layouts.footer')
@endsection
